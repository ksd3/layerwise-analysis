"""Render the conceptual and experimental diagrams used in the appendix.

The flow diagrams are made with Graphviz and the small mathematical diagrams
are made with Matplotlib.  Every figure is saved as a vector PDF for the paper
and as a PNG for quick visual review.

Run from the project directory with:

    .venv/bin/python generate_method_diagrams.py
"""

import os
import shutil
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from graphviz import Digraph
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch


# ---------------------------------------------------------------------------
# Shared paths, colors, and rendering helpers
# ---------------------------------------------------------------------------

ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = ROOT / "method_diagrams"
LOCAL_GRAPHVIZ = ROOT.parent / ".local_graphviz" / "root"

INK = "#243746"
MUTED = "#60727F"
BLUE = "#4C8FBD"
PALE_BLUE = "#DCEAF4"
TEAL = "#4E9B91"
PALE_TEAL = "#D9EEE9"
ORANGE = "#D9913D"
PALE_ORANGE = "#F7E4C7"
PURPLE = "#8064A2"
PALE_PURPLE = "#E8DFF1"
GOLD = "#D2AB36"
PALE_GOLD = "#F5EDC6"
RED = "#B75D69"
PALE_RED = "#F3DDE1"
GREY = "#E9EEF1"


plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "axes.titlesize": 12,
        "axes.titleweight": "bold",
        "axes.labelcolor": INK,
        "text.color": INK,
        "axes.edgecolor": MUTED,
        "xtick.color": MUTED,
        "ytick.color": MUTED,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    }
)


def configure_graphviz():
    """Use the local Graphviz copy when this machine has no system `dot`."""

    local_bin = LOCAL_GRAPHVIZ / "usr" / "bin"
    local_lib = LOCAL_GRAPHVIZ / "usr" / "lib" / "x86_64-linux-gnu"
    if shutil.which("dot") is None and (local_bin / "dot").exists():
        os.environ["PATH"] = str(local_bin) + os.pathsep + os.environ.get("PATH", "")
        os.environ["LD_LIBRARY_PATH"] = (
            str(local_lib) + os.pathsep + os.environ.get("LD_LIBRARY_PATH", "")
        )
        os.environ["GVBINDIR"] = str(local_lib / "graphviz")
    if shutil.which("dot") is None:
        raise RuntimeError("Graphviz `dot` was not found.")


def new_graph(name, title, rankdir="LR"):
    """Create a Graphviz canvas with the visual style used across the paper."""

    graph = Digraph(name=name, engine="dot")
    graph.attr(
        rankdir=rankdir,
        bgcolor="white",
        pad="0.22",
        nodesep="0.30",
        ranksep="0.48",
        splines="ortho",
        labelloc="t",
        labeljust="c",
        label=title,
        fontname="Helvetica-Bold",
        fontsize="20",
    )
    graph.attr(
        "node",
        shape="box",
        style="rounded,filled",
        color=INK,
        penwidth="1.0",
        fontname="Helvetica",
        fontsize="10",
        margin="0.14,0.10",
    )
    graph.attr("edge", color=MUTED, penwidth="1.25", arrowsize="0.65", fontname="Helvetica", fontsize="9")
    return graph


def render_graph(graph, filename):
    """Save one Graphviz diagram as PDF and PNG."""

    base = OUTPUT_DIR / filename
    for file_format in ("pdf", "png"):
        graph.format = file_format
        graph.render(filename=str(base), cleanup=True)


def save_matplotlib(fig, filename):
    """Save one Matplotlib diagram as PDF and a high-resolution PNG."""

    fig.savefig(OUTPUT_DIR / f"{filename}.pdf", bbox_inches="tight", facecolor="white")
    fig.savefig(OUTPUT_DIR / f"{filename}.png", dpi=220, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def box(ax, xy, width, height, text, facecolor, fontsize=10, linewidth=1.2):
    """Draw one rounded Matplotlib box and return its patch."""

    patch = FancyBboxPatch(
        xy,
        width,
        height,
        boxstyle="round,pad=0.02,rounding_size=0.04",
        facecolor=facecolor,
        edgecolor=INK,
        linewidth=linewidth,
    )
    ax.add_patch(patch)
    ax.text(xy[0] + width / 2, xy[1] + height / 2, text, ha="center", va="center", fontsize=fontsize)
    return patch


def arrow(ax, start, end, color=MUTED, connectionstyle="arc3", linestyle="-"):
    """Draw one clean arrow between Matplotlib blocks."""

    patch = FancyArrowPatch(
        start,
        end,
        arrowstyle="-|>",
        mutation_scale=12,
        linewidth=1.25,
        color=color,
        connectionstyle=connectionstyle,
        linestyle=linestyle,
    )
    ax.add_patch(patch)


# ---------------------------------------------------------------------------
# 1. The astronomical measurement chain
# ---------------------------------------------------------------------------

def measurement_chain():
    graph = new_graph(
        "measurement_chain",
        "From one physical source to a representation and a scientific label",
        rankdir="LR",
    )
    graph.node("source", "Physical source\nθ_source", fillcolor=PALE_GOLD)
    graph.node("light", "Emitted light\nspectrum + morphology", fillcolor=PALE_GOLD)
    graph.node("instrument", "Instrument response\nR_instrument", fillcolor=PALE_BLUE)
    graph.node("conditions", "Observing conditions\nc_obs", fillcolor=PALE_BLUE)
    graph.node("observation", "Recorded observation\npixels or spectrum", fillcolor=GREY)
    graph.node("foundation", "Pretrained foundation model", fillcolor=PALE_TEAL)
    graph.node("representation", "Layer representation\nZ_m,ℓ^(s)", fillcolor=PALE_TEAL)
    graph.node("inference", "Scientific inference model\nM_inference", fillcolor=PALE_PURPLE)
    graph.node("label", "Reported physical label\ny_i", fillcolor=PALE_PURPLE)

    graph.edge("source", "light")
    graph.edge("light", "instrument")
    graph.edge("instrument", "observation")
    graph.edge("conditions", "observation")
    graph.edge("observation", "foundation")
    graph.edge("foundation", "representation")
    graph.edge("observation", "inference")
    graph.edge("inference", "label")
    render_graph(graph, "01_measurement_chain")


# ---------------------------------------------------------------------------
# 2. The cross-survey data map
# ---------------------------------------------------------------------------

def cross_survey_map():
    graph = new_graph(
        "cross_survey_map",
        "The same astronomical objects seen through different surveys",
        rankdir="LR",
    )
    graph.node("hsc", "HSC\nreference optical image", fillcolor=PALE_GOLD, width="2.2")
    graph.node("desi", "DESI spectra\nn = 20,465", fillcolor=PALE_BLUE)
    graph.node("sdss", "SDSS spectra\nn = 2,319", fillcolor=PALE_BLUE)
    graph.node("legacy", "Legacy Survey images\nn = 101,725", fillcolor=PALE_TEAL)
    graph.node("jwst", "JWST images\nn = 1,496", fillcolor=PALE_TEAL)
    graph.node(
        "cosmos",
        "COSMOS-Web images\nlayerwise: n = 56,322\nfinal product: n = 45,000",
        fillcolor=PALE_ORANGE,
    )

    for survey in ("desi", "sdss", "legacy", "jwst", "cosmos"):
        graph.edge("hsc", survey, label="crossmatched objects")
    render_graph(graph, "02_cross_survey_map")


# ---------------------------------------------------------------------------
# 3. Roadmap of the nine experiments
# ---------------------------------------------------------------------------

def experiment_roadmap():
    graph = new_graph(
        "experiment_roadmap",
        "Nine experiments, organized by the question they answer",
        rankdir="TB",
    )
    graph.node("question", "When is shared geometry scientifically meaningful?", fillcolor=PALE_GOLD, width="4.0")
    graph.node("where", "WHERE DOES\nALIGNMENT APPEAR?", fillcolor=PALE_BLUE, width="2.5")
    graph.node("produce", "WHAT PRODUCES\nTHE ALIGNMENT?", fillcolor=PALE_TEAL, width="2.5")
    graph.node("physics", "DOES IT ENCODE\nSHARED PHYSICS?", fillcolor=PALE_ORANGE, width="2.5")

    graph.node("e1", "E1 · Significant anywhere\nalong the depth curve?", fillcolor="#F4F8FB")
    graph.node("e2", "E2 · Does alignment\nincrease with depth?", fillcolor="#F4F8FB")
    graph.node("e7", "E7 · Are the two views\nsynchronized across layers?", fillcolor="#F4F8FB")

    graph.node("e5", "E5 · Which block updates\nwrite shared geometry?", fillcolor="#F1F8F6")
    graph.node("e6", "E6 · Do model properties\nexplain alignment?", fillcolor="#F1F8F6")
    graph.node("e9", "E9 · Which components\nsurvive intervention?", fillcolor="#F1F8F6")

    graph.node("e3", "E3 · Does geometry select\nscientifically useful layers?", fillcolor="#FCF6EC")
    graph.node("e4", "E4 · Does a learned common\nspace rescue transfer?", fillcolor="#FCF6EC")
    graph.node("e8", "E8 · Does final alignment\npredict physical transfer?", fillcolor="#FCF6EC")

    graph.edge("question", "where")
    graph.edge("question", "produce")
    graph.edge("question", "physics")
    graph.edge("where", "e1")
    graph.edge("e1", "e2")
    graph.edge("e2", "e7")
    graph.edge("produce", "e5")
    graph.edge("e5", "e6")
    graph.edge("e6", "e9")
    graph.edge("physics", "e3")
    graph.edge("e3", "e4")
    graph.edge("e4", "e8")
    render_graph(graph, "03_experiment_roadmap")


# ---------------------------------------------------------------------------
# 4. Four different meanings of alignment
# ---------------------------------------------------------------------------

def alignment_metrics():
    rng = np.random.default_rng(7)
    fig, axes = plt.subplots(2, 2, figsize=(10.0, 7.1))
    fig.suptitle("Four different questions hidden inside “alignment”", fontsize=17, fontweight="bold", y=0.99)

    # MKNN: the coordinates can move while the local neighbor sets remain.
    ax = axes[0, 0]
    points = np.array([[0.12, 0.30], [0.25, 0.58], [0.42, 0.42], [0.60, 0.67], [0.77, 0.38], [0.91, 0.58]])
    transformed = points @ np.array([[0.85, -0.25], [0.18, 0.90]]) + np.array([1.65, 0.18])
    ax.scatter(points[:, 0], points[:, 1], s=42, c=BLUE, edgecolors=INK, linewidths=0.7, zorder=3)
    ax.scatter(transformed[:, 0], transformed[:, 1], s=42, c=TEAL, edgecolors=INK, linewidths=0.7, zorder=3)
    for cloud in (points, transformed):
        center = cloud[2]
        for neighbor in (cloud[1], cloud[3]):
            ax.plot([center[0], neighbor[0]], [center[1], neighbor[1]], color=GOLD, linewidth=2.2, zorder=2)
    ax.text(0.48, 0.90, "view A", color=BLUE, ha="center", fontweight="bold")
    ax.text(2.05, 0.90, "view B", color=TEAL, ha="center", fontweight="bold")
    ax.set_title("MKNN\nDo objects keep the same neighbors?", fontsize=11, pad=8)
    ax.set_xlim(-0.05, 2.65)
    ax.set_ylim(0.05, 1.0)
    ax.axis("off")

    # CKA: similar pairwise structure appears as similar Gram matrices.
    ax = axes[0, 1]
    base = rng.normal(size=(7, 3))
    gram_a = base @ base.T
    gram_b = (base @ np.array([[0.8, 0.2, 0.0], [-0.1, 1.0, 0.1], [0.0, 0.1, 0.9]]))
    gram_b = gram_b @ gram_b.T
    gram_a = (gram_a - gram_a.min()) / (gram_a.max() - gram_a.min())
    gram_b = (gram_b - gram_b.min()) / (gram_b.max() - gram_b.min())
    ax.imshow(np.block([[gram_a, np.ones((7, 1)) * np.nan, gram_b]]), cmap="Blues", vmin=0, vmax=1)
    label_box = {"boxstyle": "round,pad=0.2", "facecolor": "white", "edgecolor": "none", "alpha": 0.85}
    ax.text(3, 5.9, "Gram A", ha="center", color=BLUE, fontweight="bold", bbox=label_box)
    ax.text(11, 5.9, "Gram B", ha="center", color=TEAL, fontweight="bold", bbox=label_box)
    ax.set_title("CKA\nIs the global pairwise structure similar?", fontsize=11, pad=8)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)

    # Procrustes: a rotation can bring the two coordinate systems together.
    ax = axes[1, 0]
    theta = 0.75
    rotation = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
    cloud_a = rng.normal(size=(12, 2)) * np.array([0.40, 0.22])
    cloud_b = cloud_a @ rotation.T + np.array([1.6, 0.55])
    aligned_b = (cloud_b - np.array([1.6, 0.55])) @ rotation + np.array([0.0, 0.0])
    ax.scatter(cloud_a[:, 0], cloud_a[:, 1], s=34, c=BLUE, edgecolors=INK, linewidths=0.6, label="view A")
    ax.scatter(cloud_b[:, 0], cloud_b[:, 1], s=34, c=ORANGE, edgecolors=INK, linewidths=0.6, label="view B")
    ax.scatter(aligned_b[:, 0], aligned_b[:, 1], s=60, facecolors="none", edgecolors=TEAL, linewidths=1.6, label="B after rotation")
    arrow(ax, (1.30, 0.50), (0.60, 0.18), color=PURPLE, connectionstyle="arc3,rad=0.25")
    ax.set_title("Procrustes\nCan one rotation align the spaces?", fontsize=11, pad=8)
    ax.legend(frameon=False, fontsize=8, loc="lower right")
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)

    # MRR: retrieve the exact paired object rather than merely its neighbors.
    ax = axes[1, 1]
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    ax.text(0.13, 0.82, "query i", ha="center", fontweight="bold", color=BLUE)
    ax.scatter([0.13], [0.68], s=80, c=BLUE, edgecolors=INK, linewidths=0.8)
    ranks = [0.76, 0.59, 0.42, 0.25]
    labels = ["j", "i  ← exact match", "q", "r"]
    for rank, (y, label) in enumerate(zip(ranks, labels), start=1):
        color = TEAL if label.startswith("i") else GREY
        ax.add_patch(FancyBboxPatch((0.58, y - 0.045), 0.32, 0.09, boxstyle="round,pad=0.01", facecolor=color, edgecolor=INK, linewidth=0.8))
        ax.text(0.74, y, f"rank {rank}: {label}", ha="center", va="center", fontsize=9)
    arrow(ax, (0.18, 0.67), (0.57, 0.60), color=ORANGE)
    ax.set_title("MRR\nHow highly is the exact counterpart ranked?", fontsize=11, pad=8)

    fig.text(0.5, 0.012, "Conceptual schematic; no experimental values are shown.", ha="center", color=MUTED, fontsize=9)
    fig.tight_layout(rect=(0, 0.035, 1, 0.96), h_pad=2.2, w_pad=2.0)
    save_matplotlib(fig, "04_alignment_metrics")


# ---------------------------------------------------------------------------
# 5. Permutation calibration of the search over depth
# ---------------------------------------------------------------------------

def permutation_calibration():
    rng = np.random.default_rng(14)
    depth = np.linspace(0, 1, 18)
    null_curves = []
    for _ in range(70):
        noise = rng.normal(0, 0.007, size=len(depth))
        null_curves.append(np.convolve(noise, np.ones(3) / 3, mode="same"))
    null_curves = np.asarray(null_curves)
    observed = 0.010 + 0.040 * np.exp(-((depth - 0.62) / 0.18) ** 2) + rng.normal(0, 0.002, len(depth))
    null_maxima = null_curves.max(axis=1)

    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.0), gridspec_kw={"width_ratios": [1.35, 1.0]})
    fig.suptitle("Permutation calibration includes the search over every layer", fontsize=16, fontweight="bold")

    ax = axes[0]
    for curve in null_curves[:35]:
        ax.plot(depth, curve, color="#C9D2D8", linewidth=0.7, alpha=0.65)
    ax.plot(depth, observed, color=BLUE, linewidth=2.8, label="observed depth curve")
    peak = int(np.argmax(observed))
    ax.scatter(depth[peak], observed[peak], s=75, color=ORANGE, edgecolor=INK, zorder=5)
    ax.annotate("observed maximum", (depth[peak], observed[peak]), xytext=(0.16, 0.86), textcoords="axes fraction", arrowprops={"arrowstyle": "->", "color": ORANGE}, color=INK)
    ax.axhline(0, color=MUTED, linewidth=0.8)
    ax.set_xlabel("normalized model depth")
    ax.set_ylabel("alignment")
    ax.set_title("1 · Search the complete observed curve")
    ax.spines[["top", "right"]].set_visible(False)

    ax = axes[1]
    ax.hist(null_maxima, bins=13, color=GREY, edgecolor="white")
    ax.axvline(observed.max(), color=ORANGE, linewidth=3)
    ax.text(observed.max(), ax.get_ylim()[1] * 0.78, " observed\n maximum", color=ORANGE, ha="left", va="center", fontweight="bold")
    ax.set_xlabel("maximum over depth")
    ax.set_ylabel("shuffled curves")
    ax.set_title("2 · Compare maximum with null maxima")
    ax.spines[["top", "right"]].set_visible(False)

    fig.text(0.5, -0.01, "Schematic only. E1 uses 9,999 correspondence permutations and then Holm correction across 175 curves.", ha="center", color=MUTED, fontsize=9)
    fig.tight_layout(rect=(0, 0.045, 1, 0.92), w_pad=2.8)
    save_matplotlib(fig, "05_permutation_calibration")


# ---------------------------------------------------------------------------
# 6. E3 layer selection without leakage
# ---------------------------------------------------------------------------

def e3_layer_selection():
    graph = new_graph("e3_layer_selection", "E3 · Geometry-selected versus label-selected layers", rankdir="TB")
    graph.node("objects", "Crossmatched objects", fillcolor=PALE_GOLD, width="2.4")
    graph.node("fit", "FIT ROWS\nfit one ridge probe per layer", fillcolor=GREY)
    graph.node("geometry", "GEOMETRY VALIDATION\nchoose layer by paired retrieval\nno physical labels", fillcolor=PALE_BLUE)
    graph.node("labels", "LABEL VALIDATION\nchoose layer by validation R²\nphysical labels allowed", fillcolor=PALE_PURPLE)
    graph.node("test", "HELD-OUT TEST ROWS\nevaluate both selected layers\non exactly the same objects", fillcolor=PALE_ORANGE)
    graph.node("geo_layer", "ℓ_geometry", fillcolor="#F4F8FB")
    graph.node("label_layer", "ℓ_label", fillcolor="#F8F3FB")
    graph.node("comparison", "regret = R²_geometry − R²_label", fillcolor=PALE_GOLD, width="3.0")

    graph.edge("objects", "fit")
    graph.edge("objects", "geometry")
    graph.edge("objects", "labels")
    graph.edge("objects", "test")
    graph.edge("fit", "geo_layer", label="trained probes")
    graph.edge("fit", "label_layer", label="trained probes")
    graph.edge("geometry", "geo_layer")
    graph.edge("labels", "label_layer")
    graph.edge("geo_layer", "test")
    graph.edge("label_layer", "test")
    graph.edge("test", "comparison")
    render_graph(graph, "06_e3_layer_selection")


# ---------------------------------------------------------------------------
# 7. E4 common-space construction
# ---------------------------------------------------------------------------

def e4_common_space():
    graph = new_graph("e4_common_space", "E4 · Learning a common image–spectrum coordinate system", rankdir="LR")
    graph.node("hsc", "HSC representation\nX", fillcolor=PALE_BLUE)
    graph.node("spectrum", "DESI or SDSS representation\nY", fillcolor=PALE_TEAL)
    graph.node("pca_x", "Standardize + PCA\nrank 64", fillcolor="#F4F8FB")
    graph.node("pca_y", "Standardize + PCA\nrank 64", fillcolor="#F1F8F6")
    graph.node("cca", "Regularized CCA\nfit rows only", fillcolor=PALE_PURPLE, width="2.0")
    graph.node("shared_x", "Shared coordinates\nU_X", fillcolor=PALE_ORANGE)
    graph.node("shared_y", "Shared coordinates\nU_Y", fillcolor=PALE_ORANGE)
    graph.node("selection", "Geometry validation\nselect layer + ridge by MRR", fillcolor=GREY)
    graph.node("retrieval", "Held-out retrieval\nMRR", fillcolor=PALE_GOLD)
    graph.node("transfer", "Held-out redshift transfer\nR² (SDSS only)", fillcolor=PALE_GOLD)

    graph.edge("hsc", "pca_x")
    graph.edge("spectrum", "pca_y")
    graph.edge("pca_x", "cca")
    graph.edge("pca_y", "cca")
    graph.edge("cca", "shared_x")
    graph.edge("cca", "shared_y")
    graph.edge("shared_x", "selection")
    graph.edge("shared_y", "selection")
    graph.edge("selection", "retrieval")
    graph.edge("selection", "transfer")
    render_graph(graph, "07_e4_common_space")


# ---------------------------------------------------------------------------
# 8. E5 block updates
# ---------------------------------------------------------------------------

def e5_block_updates():
    graph = new_graph("e5_block_updates", "E5 · Separating what a block writes from what the state retains", rankdir="LR")
    graph.node("a0", "View A\nZ_ℓ^(a)", fillcolor=PALE_BLUE)
    graph.node("ablock", "block ℓ + 1", fillcolor=GREY)
    graph.node("a1", "View A\nZ_(ℓ+1)^(a)", fillcolor=PALE_BLUE)
    graph.node("adelta", "ΔZ_ℓ^(a) = Z_(ℓ+1)^(a) − Z_ℓ^(a)", fillcolor=PALE_ORANGE)

    graph.node("b0", "View B\nZ_ℓ^(b)", fillcolor=PALE_TEAL)
    graph.node("bblock", "block ℓ + 1", fillcolor=GREY)
    graph.node("b1", "View B\nZ_(ℓ+1)^(b)", fillcolor=PALE_TEAL)
    graph.node("bdelta", "ΔZ_ℓ^(b) = Z_(ℓ+1)^(b) − Z_ℓ^(b)", fillcolor=PALE_ORANGE)

    graph.node("state", "Hidden-state alignment\nA(Z^(a), Z^(b))", fillcolor=PALE_PURPLE)
    graph.node("update", "Update alignment\nA(ΔZ^(a), ΔZ^(b))", fillcolor=PALE_GOLD)

    graph.edge("a0", "ablock")
    graph.edge("ablock", "a1")
    graph.edge("a0", "adelta")
    graph.edge("a1", "adelta")
    graph.edge("b0", "bblock")
    graph.edge("bblock", "b1")
    graph.edge("b0", "bdelta")
    graph.edge("b1", "bdelta")
    graph.edge("a1", "state")
    graph.edge("b1", "state")
    graph.edge("adelta", "update")
    graph.edge("bdelta", "update")
    render_graph(graph, "08_e5_block_updates")


# ---------------------------------------------------------------------------
# 9. E7 all-by-all cross-layer alignment
# ---------------------------------------------------------------------------

def e7_cross_layer():
    size = 14
    row, column = np.mgrid[0:size, 0:size]
    matrix = 0.52 * np.exp(-((row - column) ** 2) / 5.0)
    matrix += 0.42 * np.exp(-((row - 9) ** 2 + (column - 7) ** 2) / 2.0)
    matrix += 0.04 * np.sin(row * 0.9) * np.cos(column * 0.7)
    matrix = (matrix - matrix.min()) / (matrix.max() - matrix.min())
    peak = np.unravel_index(np.argmax(matrix), matrix.shape)

    fig, ax = plt.subplots(figsize=(6.6, 5.7))
    image = ax.imshow(matrix, origin="lower", cmap="magma", vmin=0, vmax=1, interpolation="nearest")
    ax.plot([-0.5, size - 0.5], [-0.5, size - 0.5], color="white", linewidth=1.7, linestyle="--", label="same-depth diagonal")
    ax.scatter([peak[1]], [peak[0]], s=120, facecolors="none", edgecolors="#66D9EF", linewidths=2.2, label="all-pairs maximum")
    ax.set_xlabel("layer in view A")
    ax.set_ylabel("layer in view B")
    ax.set_title("E7 · Same depth is a hypothesis, not an assumption", pad=12)
    ax.legend(loc="upper left", frameon=True, facecolor="white", framealpha=0.92, fontsize=9)
    colorbar = fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04)
    colorbar.set_label("alignment")
    fig.text(0.5, 0.01, "Schematic cross-layer matrix; no experimental values are shown.", ha="center", color=MUTED, fontsize=9)
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    save_matplotlib(fig, "09_e7_cross_layer")


# ---------------------------------------------------------------------------
# 10. E8 within-view and cross-view transfer
# ---------------------------------------------------------------------------

def e8_transfer():
    graph = new_graph("e8_transfer", "E8 · Four readout paths on spatially separated folds", rankdir="TB")
    graph.node("folds", "45,000 crossmatched objects\ncontiguous right-ascension folds", fillcolor=PALE_GOLD, width="3.0")
    graph.node("a_train", "Train on HSC\nrepresentation A", fillcolor=PALE_BLUE)
    graph.node("b_train", "Train on COSMOS-Web\nrepresentation B", fillcolor=PALE_TEAL)
    graph.node("probe_a", "ridge probe w_A", fillcolor="#F4F8FB")
    graph.node("probe_b", "ridge probe w_B", fillcolor="#F1F8F6")
    graph.node("a_test", "Test on HSC", fillcolor=PALE_BLUE)
    graph.node("b_test", "Test on COSMOS-Web", fillcolor=PALE_TEAL)
    graph.node("within", "WITHIN VIEW\nA→A and B→B", fillcolor=PALE_PURPLE)
    graph.node("cross", "CROSS VIEW\nA→B and B→A", fillcolor=PALE_ORANGE)
    graph.node("targets", "redshift · color · magnitude\nstellar mass · specific SFR", fillcolor=GREY)
    graph.node("question", "Does geometric alignment predict cross-view R²?", fillcolor=PALE_GOLD, width="3.4")

    graph.edge("folds", "a_train")
    graph.edge("folds", "b_train")
    graph.edge("a_train", "probe_a")
    graph.edge("b_train", "probe_b")
    graph.edge("probe_a", "a_test", color=BLUE, label="A→A")
    graph.edge("probe_b", "b_test", color=TEAL, label="B→B")
    graph.edge("probe_a", "b_test", color=ORANGE, label="A→B")
    graph.edge("probe_b", "a_test", color=ORANGE, label="B→A")
    graph.edge("a_test", "within")
    graph.edge("b_test", "within")
    graph.edge("a_test", "cross")
    graph.edge("b_test", "cross")
    graph.edge("within", "targets")
    graph.edge("cross", "targets")
    graph.edge("targets", "question")
    render_graph(graph, "10_e8_transfer")


# ---------------------------------------------------------------------------
# 11. E9 interventions and negative controls
# ---------------------------------------------------------------------------

def e9_controls():
    graph = new_graph("e9_controls", "E9 · Intervening on the representation rather than merely describing it", rankdir="TB")
    graph.node("original", "Original paired final representations\n(X, Y)", fillcolor=PALE_GOLD, width="3.0")
    graph.node("negative", "NEGATIVE CONTROLS", fillcolor=PALE_RED, width="2.3")
    graph.node("components", "DIMENSION + COMPONENTS", fillcolor=PALE_BLUE, width="2.3")
    graph.node("nuisance", "NUISANCE + SENSITIVITY", fillcolor=PALE_TEAL, width="2.3")

    graph.node("shuffle", "Shuffle object\ncorrespondence", fillcolor="#FBF2F3")
    graph.node("gaussian", "Matched Gaussian\nreplacement", fillcolor="#FBF2F3")
    graph.node("projection", "Random projection\nto 32 or 64 dimensions", fillcolor="#F4F8FB")
    graph.node("pcs", "Remove leading\nprincipal components", fillcolor="#F4F8FB")
    graph.node("regress", "Regress measured\ncatalog variables", fillcolor="#F1F8F6")
    graph.node("noise", "Add isotropic noise\nto identical views", fillcolor="#F1F8F6")
    graph.node("metrics", "Recompute independently\nMKNN · CKA · Procrustes · MRR", fillcolor=PALE_PURPLE, width="3.1")
    graph.node("interpret", "Which parts of the observed agreement survive?", fillcolor=PALE_GOLD, width="3.4")

    graph.edge("original", "negative")
    graph.edge("original", "components")
    graph.edge("original", "nuisance")
    graph.edge("negative", "shuffle")
    graph.edge("negative", "gaussian")
    graph.edge("components", "projection")
    graph.edge("components", "pcs")
    graph.edge("nuisance", "regress")
    graph.edge("nuisance", "noise")
    for node in ("shuffle", "gaussian", "projection", "pcs", "regress", "noise"):
        graph.edge(node, "metrics")
    graph.edge("metrics", "interpret")
    render_graph(graph, "11_e9_controls")


# ---------------------------------------------------------------------------
# 12. Exact Gram-preserving reduction of enormous output heads
# ---------------------------------------------------------------------------

def lm_head_factorization():
    fig, ax = plt.subplots(figsize=(11.0, 5.7))
    ax.set_xlim(0, 11)
    ax.set_ylim(0, 6)
    ax.axis("off")
    ax.set_title("Replacing a 257,216-wide output without changing its row geometry", fontsize=17, pad=12)

    box(ax, (0.3, 3.8), 1.65, 1.0, "hidden states\nH  (n × h)", PALE_BLUE, fontsize=11)
    box(ax, (2.5, 3.8), 1.85, 1.0, "output weights\nWᵀ  (h × V)", PALE_PURPLE, fontsize=11)
    box(ax, (5.0, 3.8), 2.0, 1.0, "full logits\nZ = HWᵀ  (n × V)", PALE_RED, fontsize=11)
    ax.text(6.0, 3.45, "V = 152,128 or 257,216\nprohibitively large to materialize", ha="center", va="top", color=RED, fontsize=10)
    arrow(ax, (1.95, 4.3), (2.48, 4.3))
    arrow(ax, (4.35, 4.3), (4.98, 4.3))

    box(ax, (0.55, 1.15), 1.9, 1.0, "small Gram matrix\nG = WᵀW  (h × h)", PALE_PURPLE, fontsize=11)
    box(ax, (3.15, 1.15), 1.95, 1.0, "factorize\nLLᵀ = G", PALE_ORANGE, fontsize=11)
    box(ax, (5.8, 1.15), 1.95, 1.0, "reduced features\nR = HL  (n × h)", PALE_TEAL, fontsize=11)
    box(ax, (8.45, 1.15), 2.15, 1.0, "exact row geometry\nRRᵀ = ZZᵀ", PALE_GOLD, fontsize=11)
    arrow(ax, (1.55, 3.78), (1.55, 2.18), color=PURPLE)
    arrow(ax, (2.45, 1.65), (3.13, 1.65))
    arrow(ax, (5.10, 1.65), (5.78, 1.65))
    arrow(ax, (7.75, 1.65), (8.43, 1.65))

    ax.text(
        5.5,
        0.34,
        "The reduced representation preserves row inner products and norms, and therefore the cosine-neighbor geometry, linear CKA, and normalized Procrustes similarity used in the experiments.",
        ha="center",
        va="center",
        fontsize=10,
        color=INK,
        wrap=True,
    )
    save_matplotlib(fig, "12_lm_head_factorization")


def main():
    configure_graphviz()
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    diagrams = [
        measurement_chain,
        cross_survey_map,
        experiment_roadmap,
        alignment_metrics,
        permutation_calibration,
        e3_layer_selection,
        e4_common_space,
        e5_block_updates,
        e7_cross_layer,
        e8_transfer,
        e9_controls,
        lm_head_factorization,
    ]
    for number, diagram in enumerate(diagrams, start=1):
        print(f"[{number:02d}/{len(diagrams)}] {diagram.__name__}", flush=True)
        diagram()

    pdf_count = len(list(OUTPUT_DIR.glob("*.pdf")))
    png_count = len(list(OUTPUT_DIR.glob("*.png")))
    print(f"Wrote {pdf_count} PDFs and {png_count} PNGs to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
