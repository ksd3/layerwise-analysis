"""Figure 4: metric disagreement and cross-layer synchronization."""

import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import figstyle as fs

fs.apply_style()

metrics = pd.read_csv(fs.DATA / "E2_metric_analysis.csv")
pairs = pd.read_csv(fs.DATA / "E7_best_layer_pairs.csv")
pairs["offset"] = (pairs["right_layer"] - pairs["left_layer"]).abs()

assert len(pairs) == 103
assert int((pairs["offset"] == 0).sum()) == 63
assert int((pairs["offset"] <= 1).sum()) == 83

metric_order = ["corrected_overlap_20", "cka", "procrustes", "mrr"]
metric_labels = ["Local MKNN", "CKA", "Procrustes", "MRR"]
table = metrics.pivot(index="cohort", columns="metric",
                      values="fraction_positive").loc[fs.SURVEYS, metric_order]

fig, axes = plt.subplots(1, 2, figsize=(fs.TEXT_WIDTH, 1.95), layout="constrained",
                         gridspec_kw={"width_ratios": [1.02, 1.0]})
fig.get_layout_engine().set(w_pad=0.16)

# Panel a: fraction of models whose metric increases from early to final depth.
ax = axes[0]
cmap = mcolors.LinearSegmentedColormap.from_list(
    "direction", ["#d1622a", "#f2f1ee", "#2a78d6"])
values = table.to_numpy()
ax.pcolormesh(values[::-1], cmap=cmap, vmin=0, vmax=1,
              edgecolors="white", linewidth=1.6)
for row in range(values.shape[0]):
    for column in range(values.shape[1]):
        value = values[row, column]
        ink = "white" if abs(value - 0.5) > 0.33 else fs.INK
        ax.text(column + 0.5, values.shape[0] - row - 0.5, f"{value:.0%}",
                ha="center", va="center", fontsize=6.6, fontweight="bold", color=ink)
ax.set_xticks(np.arange(4) + 0.5, metric_labels)
ax.set_yticks(np.arange(5) + 0.5, [fs.SURVEY_LABEL[s] for s in fs.SURVEYS][::-1])
ax.tick_params(length=0)
ax.set_xlabel("share of models increasing from early to final depth")
for spine in ax.spines.values():
    spine.set_visible(False)
ax.set_aspect("auto")
fs.panel_letter(ax, "a", x=-0.42, y=1.04)

# Panel b: where the all-pairs cross-layer maximum sits relative to the diagonal.
ax = axes[1]
cohorts = ["legacysurvey", "jwst", "cosmosweb"]
counts = np.array([
    [(offsets == 0).sum(), (offsets == 1).sum(), (offsets > 1).sum()]
    for cohort in cohorts
    for offsets in [pairs.loc[pairs["cohort"] == cohort, "offset"]]
], dtype=float)
percent = 100 * counts / counts.sum(axis=1, keepdims=True)

offset_colors = ["#33475b", "#6d8396", "#cfd8df"]  # ordinal: distance from diagonal
offset_labels = ["same layer", "adjacent layer", ">1 layer apart"]
rows = np.arange(len(cohorts))
left = np.zeros(len(cohorts))
for column, (label, color) in enumerate(zip(offset_labels, offset_colors)):
    ax.barh(rows, percent[:, column], left=left, height=0.55, color=color,
            label=label, edgecolor="white", linewidth=1.2)
    for row in rows:
        if percent[row, column] >= 8:
            ax.text(left[row] + percent[row, column] / 2, row,
                    str(int(counts[row, column])), ha="center", va="center",
                    fontsize=6.4, fontweight="bold",
                    color="white" if column < 2 else fs.INK)
    left += percent[:, column]
ax.set_yticks(rows, [fs.SURVEY_LABEL[c] for c in cohorts])
ax.invert_yaxis()
ax.tick_params(axis="y", length=0)
ax.set_xlim(0, 100)
ax.set_xticks([0, 25, 50, 75, 100])
ax.set_xlabel("share of models (%)")
ax.legend(frameon=False, loc="upper left", bbox_to_anchor=(-0.02, 1.14), ncols=3,
          borderpad=0, handlelength=1.0, handleheight=0.9, columnspacing=1.1,
          handletextpad=0.5)
fs.style_axis(ax, grid=None)
fs.panel_letter(ax, "b", x=-0.36, y=1.04)

fs.save(fig, "04_metric_and_layer_timing")
