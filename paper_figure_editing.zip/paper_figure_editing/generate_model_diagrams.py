"""Generate compact TorchViz block diagrams for every model in the paper.

The raw TorchViz graph of a large model contains millions of parameter and
autograd nodes.  That is useful for debugging code, but not for a paper.  This
script traces a small PyTorch skeleton with the same ordered model blocks and
then cleans up the TorchViz labels.  Repeated blocks are collapsed into one
box marked with their count.  The counts and widths come from the E1 layerwise
files that were actually analyzed.

Run from the project directory with:

    .venv/bin/python generate_model_diagrams.py

The PDFs and review PNGs are written to paper_neurips2026/model_diagrams/.
On this computer, the script uses the locally extracted Graphviz executable in
.local_graphviz/.  A normal system Graphviz installation works as well.
"""

import csv
import os
import re
import shutil
from pathlib import Path

import torch
from graphviz import Digraph
from torchviz import make_dot


# ---------------------------------------------------------------------------
# Paths and model metadata
# ---------------------------------------------------------------------------

ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = ROOT / "model_diagrams"
LOCAL_GRAPHVIZ = ROOT.parent / ".local_graphviz" / "root"


def configure_graphviz():
    """Make the local Graphviz binary visible when no system `dot` exists."""

    local_bin = LOCAL_GRAPHVIZ / "usr" / "bin"
    local_lib = LOCAL_GRAPHVIZ / "usr" / "lib" / "x86_64-linux-gnu"

    if shutil.which("dot") is None and (local_bin / "dot").exists():
        os.environ["PATH"] = str(local_bin) + os.pathsep + os.environ.get("PATH", "")
        os.environ["LD_LIBRARY_PATH"] = (
            str(local_lib) + os.pathsep + os.environ.get("LD_LIBRARY_PATH", "")
        )
        os.environ["GVBINDIR"] = str(local_lib / "graphviz")

    if shutil.which("dot") is None:
        raise RuntimeError("Graphviz `dot` was not found.")


def load_model_basket():
    """Read the exact set of models present in the completed E1 analysis."""

    path = ROOT / "E1_model_peaks.csv"
    with path.open(newline="") as handle:
        models = sorted({row["model"] for row in csv.DictReader(handle)})
    return models


def load_parameter_counts():
    """Read one parameter count for each model from the E6 summary table."""

    path = ROOT / "E6_model_table.csv"
    counts = {}
    with path.open(newline="") as handle:
        for row in csv.DictReader(handle):
            counts[row["model"]] = float(row["parameters_m"])
    return counts


# A stage is (box title, box detail, color group).  These are compact versions
# of the layer sequences in E1/*/<model>/curve.csv.  Only repeated blocks are
# collapsed; their number and representation width are retained.
MODEL_SPECS = {
    "astropt_015M": [("Transformer blocks ×6", "d = 384", "encoder"), ("Embedding output", "d = 384", "output")],
    "astropt_095M": [("Transformer blocks ×12", "d = 768", "encoder"), ("Embedding output", "d = 768", "output")],
    "astropt_850M": [("Transformer blocks ×16", "d = 2,048", "encoder"), ("Embedding output", "d = 2,048", "output")],
    "clip_base": [("Patch + position embeddings", "d = 768", "input"), ("Pre-LayerNorm", "d = 768", "normalization"), ("Vision transformer blocks ×12", "d = 768", "encoder"), ("Post-LayerNorm", "d = 768", "normalization"), ("Visual projection", "768 → 512", "projection"), ("Model representation", "d = 512", "output")],
    "clip_large": [("Patch + position embeddings", "d = 1,024", "input"), ("Pre-LayerNorm", "d = 1,024", "normalization"), ("Vision transformer blocks ×24", "d = 1,024", "encoder"), ("Post-LayerNorm", "d = 1,024", "normalization"), ("Visual projection", "1,024 → 768", "projection"), ("Model representation", "d = 768", "output")],
    "convnext_nano": [("Patch embedding", "d = 80", "input"), ("ConvNeXt stage 1 ×2", "d = 80", "convolution"), ("Downsample + stage 2 ×2", "d = 160", "convolution"), ("Downsample + stage 3 ×8", "d = 320", "convolution"), ("Downsample + stage 4 ×2", "d = 640", "convolution"), ("LayerNorm + representation", "d = 640", "output")],
    "convnext_tiny": [("Patch embedding", "d = 96", "input"), ("ConvNeXt stage 1 ×3", "d = 96", "convolution"), ("Downsample + stage 2 ×3", "d = 192", "convolution"), ("Downsample + stage 3 ×9", "d = 384", "convolution"), ("Downsample + stage 4 ×3", "d = 768", "convolution"), ("LayerNorm + representation", "d = 768", "output")],
    "convnext_base": [("Patch embedding", "d = 128", "input"), ("ConvNeXt stage 1 ×3", "d = 128", "convolution"), ("Downsample + stage 2 ×3", "d = 256", "convolution"), ("Downsample + stage 3 ×27", "d = 512", "convolution"), ("Downsample + stage 4 ×3", "d = 1,024", "convolution"), ("LayerNorm + representation", "d = 1,024", "output")],
    "convnext_large": [("Patch embedding", "d = 192", "input"), ("ConvNeXt stage 1 ×3", "d = 192", "convolution"), ("Downsample + stage 2 ×3", "d = 384", "convolution"), ("Downsample + stage 3 ×27", "d = 768", "convolution"), ("Downsample + stage 4 ×3", "d = 1,536", "convolution"), ("LayerNorm + representation", "d = 1,536", "output")],
    "dino_small": [("Patch embedding", "d = 384", "input"), ("Transformer encoder blocks ×12", "d = 384", "encoder"), ("LayerNorm + representation", "d = 384", "output")],
    "dino_base": [("Patch embedding", "d = 768", "input"), ("Transformer encoder blocks ×12", "d = 768", "encoder"), ("LayerNorm + representation", "d = 768", "output")],
    "dino_large": [("Patch embedding", "d = 1,024", "input"), ("Transformer encoder blocks ×24", "d = 1,024", "encoder"), ("LayerNorm + representation", "d = 1,024", "output")],
    "dino_giant": [("Patch embedding", "d = 1,536", "input"), ("Transformer encoder blocks ×40", "d = 1,536", "encoder"), ("LayerNorm + representation", "d = 1,536", "output")],
    "dinov3_vits16": [("Patch embedding", "d = 384", "input"), ("DINOv3 encoder blocks ×12", "d = 384", "encoder"), ("LayerNorm + representation", "d = 384", "output")],
    "dinov3_vits16plus": [("Patch embedding", "d = 384", "input"), ("DINOv3 encoder blocks ×12", "d = 384", "encoder"), ("LayerNorm + representation", "d = 384", "output")],
    "dinov3_vitb16": [("Patch embedding", "d = 768", "input"), ("DINOv3 encoder blocks ×12", "d = 768", "encoder"), ("LayerNorm + representation", "d = 768", "output")],
    "dinov3_vitl16": [("Patch embedding", "d = 1,024", "input"), ("DINOv3 encoder blocks ×24", "d = 1,024", "encoder"), ("LayerNorm + representation", "d = 1,024", "output")],
    "dinov3_vith16plus": [("Patch embedding", "d = 1,280", "input"), ("DINOv3 encoder blocks ×32", "d = 1,280", "encoder"), ("LayerNorm + representation", "d = 1,280", "output")],
    "dinov3_vit7b16": [("Patch embedding", "d = 4,096", "input"), ("DINOv3 encoder blocks ×40", "d = 4,096", "encoder"), ("LayerNorm + representation", "d = 4,096", "output")],
    "ijepa_huge": [("Patch embedding", "d = 1,280", "input"), ("I-JEPA encoder blocks ×32", "d = 1,280", "encoder"), ("LayerNorm + representation", "d = 1,280", "output")],
    "ijepa_giant": [("Patch embedding", "d = 1,408", "input"), ("I-JEPA encoder blocks ×40", "d = 1,408", "encoder"), ("LayerNorm + representation", "d = 1,408", "output")],
    "llava_15_7b": [("Vision tower blocks ×24", "d = 1,024", "vision"), ("Multimodal projector", "vision → language", "projection"), ("Language decoder blocks ×32", "d = 4,096", "language"), ("LM head", "factorized in analysis", "projection"), ("Model representation", "d = 4,096", "output")],
    "llava_15_13b": [("Vision tower blocks ×24", "d = 1,024", "vision"), ("Multimodal projector", "vision → language", "projection"), ("Language decoder blocks ×40", "d = 5,120", "language"), ("LM head", "factorized in analysis", "projection"), ("Model representation", "d = 5,120", "output")],
    "llava_ov_7b": [("Vision features + projector", "not layerwise in artifact", "vision"), ("Language decoder blocks ×28", "d = 3,584", "language"), ("LM head", "factorized in analysis", "projection"), ("Model representation", "d = 3,584", "output")],
    "paligemma_3b": [("Vision tower blocks ×27", "d = 1,152", "vision"), ("Multimodal projector", "vision → language", "projection"), ("Language decoder blocks ×26", "d = 2,304", "language"), ("LM head", "factorized in analysis", "projection"), ("Model representation", "d = 2,304", "output")],
    "paligemma_10b": [("Vision tower blocks ×27", "d = 1,152", "vision"), ("Multimodal projector", "vision → language", "projection"), ("Language decoder blocks ×42", "d = 3,584", "language"), ("LM head", "factorized in analysis", "projection"), ("Model representation", "d = 3,584", "output")],
    "paligemma_28b": [("Vision tower blocks ×27", "d = 1,152", "vision"), ("Multimodal projector", "vision → language", "projection"), ("Language decoder blocks ×46", "d = 4,608", "language"), ("LM head", "factorized in analysis", "projection"), ("Model representation", "d = 4,608", "output")],
    "vit-mae_base": [("Patch embedding", "d = 768", "input"), ("MAE transformer blocks ×12", "d = 768", "encoder"), ("LayerNorm + representation", "d = 768", "output")],
    "vit-mae_large": [("Patch embedding", "d = 1,024", "input"), ("MAE transformer blocks ×24", "d = 1,024", "encoder"), ("LayerNorm + representation", "d = 1,024", "output")],
    "vit-mae_huge": [("Patch embedding", "d = 1,280", "input"), ("MAE transformer blocks ×32", "d = 1,280", "encoder"), ("LayerNorm + representation", "d = 1,280", "output")],
    "vit_base": [("Patch embedding", "d = 768", "input"), ("Transformer encoder blocks ×12", "d = 768", "encoder"), ("LayerNorm + pooler", "d = 768", "normalization"), ("Model representation", "d = 768", "output")],
    "vit_large": [("Patch embedding", "d = 1,024", "input"), ("Transformer encoder blocks ×24", "d = 1,024", "encoder"), ("LayerNorm + pooler", "d = 1,024", "normalization"), ("Model representation", "d = 1,024", "output")],
    "vit_huge": [("Patch embedding", "d = 1,280", "input"), ("Transformer encoder blocks ×32", "d = 1,280", "encoder"), ("LayerNorm + pooler", "d = 1,280", "normalization"), ("Model representation", "d = 1,280", "output")],
    "vjepa_large": [("Video tokenization", "d = 1,024", "input"), ("V-JEPA encoder blocks ×24", "d = 1,024", "encoder"), ("Predictor blocks ×12", "d = 384", "predictor"), ("Model representation", "d = 1,024", "output")],
    "vjepa_huge": [("Video tokenization", "d = 1,280", "input"), ("V-JEPA encoder blocks ×32", "d = 1,280", "encoder"), ("Predictor blocks ×12", "d = 384", "predictor"), ("Model representation", "d = 1,280", "output")],
    "vjepa_giant": [("Video tokenization", "d = 1,408", "input"), ("V-JEPA encoder blocks ×40", "d = 1,408", "encoder"), ("Predictor blocks ×12", "d = 384", "predictor"), ("Model representation", "d = 1,408", "output")],
}


DISPLAY_NAMES = {
    "astropt_015M": "AstroPT 15M",
    "astropt_095M": "AstroPT 95M",
    "astropt_850M": "AstroPT 850M",
    "clip_base": "CLIP Base",
    "clip_large": "CLIP Large",
    "convnext_nano": "ConvNeXt Nano",
    "convnext_tiny": "ConvNeXt Tiny",
    "convnext_base": "ConvNeXt Base",
    "convnext_large": "ConvNeXt Large",
    "dino_small": "DINO Small",
    "dino_base": "DINO Base",
    "dino_large": "DINO Large",
    "dino_giant": "DINO Giant",
    "dinov3_vits16": "DINOv3 ViT-S/16",
    "dinov3_vits16plus": "DINOv3 ViT-S+/16",
    "dinov3_vitb16": "DINOv3 ViT-B/16",
    "dinov3_vitl16": "DINOv3 ViT-L/16",
    "dinov3_vith16plus": "DINOv3 ViT-H+/16",
    "dinov3_vit7b16": "DINOv3 ViT-7B/16",
    "ijepa_huge": "I-JEPA Huge",
    "ijepa_giant": "I-JEPA Giant",
    "llava_15_7b": "LLaVA-1.5 7B",
    "llava_15_13b": "LLaVA-1.5 13B",
    "llava_ov_7b": "LLaVA-OneVision 7B",
    "paligemma_3b": "PaliGemma 3B",
    "paligemma_10b": "PaliGemma 10B",
    "paligemma_28b": "PaliGemma 28B",
    "vit-mae_base": "ViT-MAE Base",
    "vit-mae_large": "ViT-MAE Large",
    "vit-mae_huge": "ViT-MAE Huge",
    "vit_base": "ViT Base",
    "vit_large": "ViT Large",
    "vit_huge": "ViT Huge",
    "vjepa_large": "V-JEPA Large",
    "vjepa_huge": "V-JEPA Huge",
    "vjepa_giant": "V-JEPA Giant",
}


COLORS = {
    "input": "#DCE8F2",
    "encoder": "#A8CBE8",
    "vision": "#85B6DA",
    "convolution": "#A8D5BA",
    "normalization": "#E4E8EB",
    "projection": "#D8C3E8",
    "language": "#F3C88D",
    "predictor": "#E8B6C4",
    "output": "#F1E6A8",
}


# ---------------------------------------------------------------------------
# TorchViz tracing and paper-style cleanup
# ---------------------------------------------------------------------------

def make_trace_stage(index):
    """Create a named identity operation that appears as one TorchViz node."""

    def forward(ctx, x):
        return x.clone()

    def backward(ctx, gradient):
        return gradient

    return type(
        f"DiagramStage{index:02d}",
        (torch.autograd.Function,),
        {"forward": staticmethod(forward), "backward": staticmethod(backward)},
    )


def trace_model(stages):
    """Trace the ordered block skeleton with TorchViz."""

    value = torch.ones(1, requires_grad=True)
    for index in range(len(stages)):
        stage = make_trace_stage(index)
        value = stage.apply(value)
    return make_dot(value)


def clean_torchviz_graph(raw_graph, model, stages, parameters_m):
    """Turn the raw autograd trace into a readable architecture diagram."""

    output_id = None
    input_tensor_id = None
    accumulate_id = None

    for line in raw_graph.body:
        node_match = re.match(r"\s*(\d+) \[", line)
        if not node_match:
            continue
        node_id = node_match.group(1)
        if "darkolivegreen1" in line:
            output_id = node_id
        elif "lightblue" in line:
            input_tensor_id = node_id
        elif "AccumulateGrad" in line:
            accumulate_id = node_id

    if output_id is None or accumulate_id is None:
        raise RuntimeError(f"Could not parse the TorchViz trace for {model}.")

    if parameters_m >= 1000:
        parameter_text = f"{parameters_m / 1000:g}B"
    else:
        parameter_text = f"{parameters_m:g}M"

    graph = Digraph(name=model, format="pdf", engine="dot")
    graph.attr(
        rankdir="TB",
        bgcolor="white",
        pad="0.18",
        nodesep="0.18",
        ranksep="0.26",
        splines="ortho",
        labelloc="t",
        labeljust="c",
        fontname="Helvetica-Bold",
        fontsize="18",
        label=f"{DISPLAY_NAMES[model]}  ·  {parameter_text} parameters",
    )
    graph.attr(
        "node",
        shape="box",
        style="rounded,filled",
        color="#40515F",
        penwidth="1.0",
        fontname="Helvetica",
        fontsize="10",
        margin="0.12,0.08",
        width="2.65",
    )
    graph.attr("edge", color="#60727F", penwidth="1.2", arrowsize="0.65")

    # Keep the ordering discovered by TorchViz, but replace implementation
    # labels such as DiagramStage03Backward with scientific block names.
    graph.node("input", "Astronomical observation", fillcolor="#F5F6F7")
    previous = "input"
    for index, (title, detail, group) in enumerate(stages):
        node = f"stage_{index:02d}"
        graph.node(node, f"{title}\n{detail}", fillcolor=COLORS[group])
        graph.edge(previous, node)
        previous = node
    graph.node("output", "Representation used in experiments", fillcolor="#F7F2D0")
    graph.edge(previous, "output")

    # Store the original trace identifiers as a comment in the DOT source.
    # This makes it explicit that the clean graph came from a TorchViz trace.
    graph.comment = (
        f"TorchViz trace: input_tensor={input_tensor_id}, "
        f"accumulate_grad={accumulate_id}, output_tensor={output_id}"
    )
    return graph


def write_index(rows):
    """Write a small manifest for checking the generated figure set."""

    path = OUTPUT_DIR / "diagram_index.csv"
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["model", "display_name", "parameters_m", "blocks", "pdf", "png"],
        )
        writer.writeheader()
        writer.writerows(rows)


def main():
    configure_graphviz()
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    basket = load_model_basket()
    parameters = load_parameter_counts()
    expected = sorted(MODEL_SPECS)
    if basket != expected:
        missing = sorted(set(basket) - set(expected))
        extra = sorted(set(expected) - set(basket))
        raise RuntimeError(f"Model specification mismatch. Missing={missing}; extra={extra}")

    rows = []
    for number, model in enumerate(basket, start=1):
        print(f"[{number:02d}/{len(basket)}] {DISPLAY_NAMES[model]}", flush=True)
        raw_graph = trace_model(MODEL_SPECS[model])
        graph = clean_torchviz_graph(raw_graph, model, MODEL_SPECS[model], parameters[model])
        base = OUTPUT_DIR / model

        graph.format = "pdf"
        pdf_path = Path(graph.render(filename=str(base), cleanup=True))
        graph.format = "png"
        png_path = Path(graph.render(filename=str(base), cleanup=True))

        rows.append(
            {
                "model": model,
                "display_name": DISPLAY_NAMES[model],
                "parameters_m": parameters[model],
                "blocks": len(MODEL_SPECS[model]),
                "pdf": pdf_path.name,
                "png": png_path.name,
            }
        )

    write_index(rows)
    print(f"Wrote {len(rows)} PDF diagrams and {len(rows)} PNG diagrams to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
