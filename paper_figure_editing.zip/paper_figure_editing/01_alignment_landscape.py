"""Figure 1: alignment is widespread, survey-dependent, and rarely final-layer."""

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

import figstyle as fs

# seaborn first: set_theme() overwrites rcParams, so the house style has to win.
sns.set_theme(style="ticks")
fs.apply_style()

curves = pd.read_csv(fs.DATA / "E1_average_depth_curves.csv")
summary = pd.read_csv(fs.DATA / "E1_cohort_summary.csv").set_index("cohort")

plot_data = curves.copy()
plot_data["cohort_name"] = plot_data["cohort"].map(fs.SURVEY_LABEL)
plot_data = plot_data.sort_values(["cohort", "normalized_depth"])

# Cohort peaks span 400x (JWST 17%, SDSS 0.04%), so a shared linear y-axis would
# flatten four of the five panels.  Each panel therefore keeps its own axis,
# anchored at zero and topped just above its own peak -- which means every panel
# spans an identical *fraction* of its peak.  Shape is then comparable across
# panels even though the absolute scale is not, and the ghost curves below can
# be drawn in that shared fractional frame.
peaks = {c: float(g["mean_alignment"].max()) for c, g in curves.groupby("cohort")}
HEADROOM = 1.12

# Every cohort's curve as a fraction of its own peak: the reference layer that
# gets repeated faintly behind every panel.
ghosts = {
    c: (g["normalized_depth"].to_numpy(), g["mean_alignment"].to_numpy() / peaks[c])
    for c, g in curves.groupby("cohort")
}

g = sns.FacetGrid(
    plot_data,
    col="cohort_name",
    col_order=[fs.SURVEY_LABEL[c] for c in fs.SURVEYS],
    height=1.32,
    aspect=0.83,
    sharex=True,
    sharey=False,
)
g.set_titles("")  # drop the "cohort_name = X" template titles


def plot_curve(data, **kwargs):
    ax = plt.gca()
    cohort = data.iloc[0]["cohort"]
    color = fs.SURVEY_COLOR[cohort]
    x = data["normalized_depth"].to_numpy()
    mean = data["mean_alignment"].to_numpy()
    se = data["standard_error"].to_numpy()

    # Ghost layer, drawn in peak-normalized units on a hidden twin axis. The
    # panel's own cohort is omitted -- its coloured curve lands exactly on top
    # of where its ghost would be, because both axes are scaled to the peak.
    ghost_ax = ax.twinx()
    ghost_ax.set_ylim(0, HEADROOM)
    ghost_ax.set_axis_off()
    for other, (gx, gy) in ghosts.items():
        if other == cohort:
            continue
        ghost_ax.plot(gx, gy, color=fs.AXIS, linewidth=0.45, alpha=0.5,
                      solid_joinstyle="miter", zorder=1)

    ax.fill_between(x, np.clip(mean - se, 0, None), mean + se,
                    color=color, alpha=0.18, linewidth=0, zorder=2)
    # Thin, hard-cornered segments: the curve is 20 sampled depth bins, so let it
    # read as the piecewise-linear interpolation it actually is.
    ax.plot(x, mean, color=color, linewidth=0.9, solid_capstyle="butt",
            solid_joinstyle="miter", zorder=3)

    peak = int(np.nanargmax(mean))
    ax.scatter(x[peak], mean[peak], s=8, color=color, edgecolor="white",
               linewidth=0.5, zorder=5)
    ax.axvline(summary.loc[cohort, "median_peak_depth"], color=fs.INK,
               linewidth=0.7, linestyle=(0, (2.6, 2.2)), alpha=0.45, zorder=4)


g.map_dataframe(plot_curve)
g.refline(y=0, color=fs.MUTED, linewidth=0.6, linestyle="-")

for ax, cohort in zip(g.axes.flat, fs.SURVEYS):
    ax.set_xlim(-0.02, 1.02)
    ax.set_xticks([0, 0.5, 1])
    ax.set_xticklabels(["0", "0.5", "1"])
    ax.set_xlabel("")

    # Anchored at zero, topped at the same multiple of the peak in every panel.
    ax.set_ylim(0, peaks[cohort] * HEADROOM)
    ax.yaxis.set_major_locator(plt.MaxNLocator(3, steps=[1, 2, 2.5, 5, 10]))
    ax.yaxis.set_major_formatter(
        plt.FuncFormatter(lambda v, _: f"{100 * v:g}")
    )
    ax.set_ylabel("")
    fs.style_axis(ax)
    # Title carries the survey colour, so the heading and its curve are the same
    # ink and the bold weight is no longer doing that work.
    ax.set_title(fs.SURVEY_LABEL[cohort], fontsize=7.0, loc="left", pad=6,
                 fontweight="normal", color=fs.SURVEY_COLOR[cohort])

g.axes.flat[0].set_ylabel("mean MKNN (%)")
g.axes.flat[2].set_xlabel("normalized depth")

g.figure.tight_layout(w_pad=0.6, pad=0.2)

g.savefig(f"{fs.HERE}/01_alignment_landscape.pdf",
          bbox_inches="tight", pad_inches=0.02, facecolor="white")
g.savefig(f"{fs.HERE}/01_alignment_landscape.png", dpi=300,
          bbox_inches="tight", pad_inches=0.02, facecolor="white")
plt.close()
