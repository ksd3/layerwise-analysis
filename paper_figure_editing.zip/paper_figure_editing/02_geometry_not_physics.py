"""Figure 2: shared geometry does not imply a shared physical readout.

One axis, one currency: held-out R², where zero means "no better than
predicting the mean".  Gray marks the supervised path (label-selected layer,
within-survey readout); red marks what happens when the shared geometry is
trusted instead (geometry-selected layer, cross-survey transfer).
"""

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D

import figstyle as fs

fs.apply_style()

transfer = pd.read_csv(fs.DATA / "E3_model_transfer.csv")
inference = pd.read_csv(fs.DATA / "E3_inference_analysis.csv").set_index(
    ["cohort", "target", "direction"])
models = pd.read_csv(fs.DATA / "E8_model_analysis.csv")

# Family means first, then the mean across families — the same aggregation
# that produced the published mean regret (reproduced below to machine
# precision as a consistency check).
family = transfer.groupby(["cohort", "target", "direction", "family"])[
    ["label_free_test_r2", "oracle_test_r2"]].mean()
tests = family.groupby(["cohort", "target", "direction"]).mean()
regret = tests["label_free_test_r2"] - tests["oracle_test_r2"]
assert np.allclose(regret, inference.loc[regret.index, "mean_regret"])
assert (regret < 0).all() and len(regret) == 8
assert (models["cross_view_redshift_r2"] < 0).all() and len(models) == 31

order = [
    ("legacysurvey", "g_minus_r", "hsc_to_other"),
    ("legacysurvey", "g_minus_r", "other_to_hsc"),
    ("legacysurvey", "log_shape", "hsc_to_other"),
    ("legacysurvey", "log_shape", "other_to_hsc"),
    ("jwst", "mag_auto", "hsc_to_other"),
    ("jwst", "mag_auto", "other_to_hsc"),
    ("jwst", "log_flux_radius", "hsc_to_other"),
    ("jwst", "log_flux_radius", "other_to_hsc"),
]
target_label = {"g_minus_r": "color", "log_shape": "shape",
                "mag_auto": "magnitude", "log_flux_radius": "size"}
survey_short = {"legacysurvey": "Legacy", "jwst": "JWST"}
row_labels = []
for cohort, target, direction in order:
    ends = ("HSC", survey_short[cohort])
    a, b = ends if direction == "hsc_to_other" else ends[::-1]
    row_labels.append(f"{target_label[target]} · {a} → {b}")
row_labels += ["redshift · within survey", "redshift · across surveys"]

SUPERVISED = "#8fa2b3"
fig, ax = plt.subplots(figsize=(3.7, 2.8), layout="constrained")

# Block 1 (rows 0-7): the same test set scored twice — layer picked by
# labels versus layer picked by geometry.
for row, key in enumerate(order):
    ax.plot([tests.loc[key, "oracle_test_r2"], tests.loc[key, "label_free_test_r2"]],
            [row, row], color=fs.GRID, linewidth=1.0, zorder=2)
    ax.scatter(tests.loc[key, "oracle_test_r2"], row, s=15, color=SUPERVISED,
               edgecolor="white", linewidth=0.5, zorder=4)
    ax.scatter(tests.loc[key, "label_free_test_r2"], row, s=15, color=fs.RED,
               edgecolor="white", linewidth=0.5, zorder=4)

# Block 2 (two strip rows): within-survey readout versus cross-survey
# transfer of the same 31 aligned model pairs.
rng = np.random.default_rng(7)
for center, column, color in ((9.3, "within_view_redshift_r2", SUPERVISED),
                              (10.8, "cross_view_redshift_r2", fs.RED)):
    values = models[column].to_numpy()
    ax.scatter(values, center + rng.uniform(-0.4, 0.4, len(values)), s=8,
               color=color, alpha=0.75, edgecolor="white", linewidth=0.25, zorder=3)

ax.axvspan(-32, 0, color=fs.WASH_RED, zorder=0)
ax.axvline(0, color=fs.INK, linewidth=0.8)
ax.axhline(8.3, color=fs.GRID, linewidth=0.6)

ax.set_xscale("symlog", linthresh=1.0, linscale=1.2)
ax.set_xlim(-32, 1.02)
ax.set_xticks([1, 0.5, 0, -0.5, -1, -3, -10, -30],
              ["1", "0.5", "0", "−0.5", "−1", "−3", "−10", "−30"])
ax.minorticks_off()
ax.set_yticks(list(range(8)) + [9.3, 10.8], row_labels)
ax.tick_params(axis="y", length=0)
ax.set_ylim(11.6, -1.0)
ax.set_xlabel("held-out R²")

ax.text(-0.06, -0.45, "← worse than predicting the mean", ha="right", va="center",
        fontsize=5.8, color=fs.MUTED)
handles = [
    Line2D([], [], marker="o", linestyle="none", markersize=3.6,
           markerfacecolor=SUPERVISED, markeredgecolor="white",
           markeredgewidth=0.5, label="layer picked by labels"),
    Line2D([], [], marker="o", linestyle="none", markersize=3.6,
           markerfacecolor=fs.RED, markeredgecolor="white",
           markeredgewidth=0.5, label="layer picked by geometry"),
]
ax.legend(handles=handles, frameon=False, loc="lower left",
          bbox_to_anchor=(-0.02, 1.0), ncols=2, borderpad=0, fontsize=5.8,
          handlelength=0.8, columnspacing=1.0, handletextpad=0.4,
          borderaxespad=0.2)
fs.style_axis(ax, grid="x")

fs.save(fig, "02_geometry_not_physics")
