"""Figure 3: block updates versus the accumulated hidden state."""

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.lines import Line2D

import figstyle as fs

# seaborn first: set_theme() overwrites rcParams, so the house style has to win.
sns.set_theme(style="ticks")
fs.apply_style()

updates = pd.read_csv(fs.DATA / "E5_model_update_peaks.csv")
states = pd.read_csv(fs.DATA / "E1_model_peaks.csv")[
    ["cohort", "model", "corrected_overlap_20", "normalized_depth"]
].rename(columns={"corrected_overlap_20": "state_peak", "normalized_depth": "state_peak_depth"})
frame = updates.merge(states, on=["cohort", "model"], validate="one_to_one")

# Compute variables
frame["log2_ratio"] = np.log2(frame["maximum_update_alignment"] / frame["state_peak"])
frame["depth_difference"] = frame["normalized_depth"] - frame["state_peak_depth"]
stronger = int((frame["log2_ratio"] > 0).sum())
earlier = int((frame["depth_difference"] < 0).sum())
assert (stronger, earlier, len(frame)) == (63, 119, 175)

# The cloud is tight around the origin (IQR is +-0.07 in x, +-0.11 in y) with a
# thin tail out to +-0.9.  Framing on the tail wastes the panel, so the axes are
# cut at +-0.5 / +-1 log2 and the tail is pinned to the edge as chevrons.
XLIM, YLIM = 0.5, 1.05
inside = (frame["depth_difference"].abs() <= XLIM) & (frame["log2_ratio"].abs() <= YLIM)
core, tail = frame[inside], frame[~inside]

g = sns.JointGrid(
    data=core,
    x="depth_difference",
    y="log2_ratio",
    height=3.3,
    ratio=5,
    space=0.12,
    marginal_ticks=False,
)

# Density underlay carries the concentration; the colorbar it used to need is
# redundant next to the marginals, so it is gone.
sns.kdeplot(
    data=core, x="depth_difference", y="log2_ratio",
    ax=g.ax_joint, fill=True, cmap="Blues", levels=5, thresh=0.12,
    bw_adjust=1.25, alpha=0.45, zorder=1,
)

sns.scatterplot(
    data=core, x="depth_difference", y="log2_ratio",
    hue="cohort", hue_order=fs.SURVEYS, palette=fs.SURVEY_COLOR,
    s=11, alpha=0.85, edgecolor="none", legend=False, ax=g.ax_joint, zorder=3,
)

# Marginals, with the "earlier" / "stronger" side of each washed in.
g.plot_marginals(sns.histplot, element="step", bins=28,
                 color=fs.MUTED, linewidth=0.7, alpha=0.25)
g.ax_marg_x.axvspan(-XLIM, 0, color=fs.WASH_BLUE, zorder=0)
g.ax_marg_y.axhspan(0, YLIM, color=fs.WASH_BLUE, zorder=0)

ax = g.ax_joint

# Out-of-range models, pinned to the edge they left through.
for _, row in tail.iterrows():
    x = float(np.clip(row["depth_difference"], -XLIM * 0.985, XLIM * 0.985))
    y = float(np.clip(row["log2_ratio"], -YLIM * 0.985, YLIM * 0.985))
    if abs(row["log2_ratio"]) > YLIM:
        marker = "^" if row["log2_ratio"] > 0 else "v"
    else:
        marker = ">" if row["depth_difference"] > 0 else "<"
    ax.plot(x, y, marker=marker, markersize=2.6, linestyle="none",
            color=fs.SURVEY_COLOR[row["cohort"]], alpha=0.9,
            zorder=4)

# Reference lines
ax.axvline(0, color=fs.INK, linewidth=0.7, zorder=2)
ax.axhline(0, color=fs.INK, linewidth=0.7, zorder=2)

# Axes
ax.set_xlim(-XLIM, XLIM)
ax.set_xticks([-0.5, -0.25, 0, 0.25, 0.5])
ax.set_xticklabels(["−0.5", "−0.25", "0", "0.25", "0.5"])
ax.set_ylim(-YLIM, YLIM)
ax.set_yticks([-1, -0.5, 0, 0.5, 1])
ax.set_yticklabels(["½×", "0.7×", "1×", "1.4×", "2×"])
ax.set_xlabel("update peak depth − state peak depth")
ax.set_ylabel("update peak / state peak")
fs.style_axis(ax, grid=None)
for marg in (g.ax_marg_x, g.ax_marg_y):
    marg.spines[["top", "right", "left", "bottom"]].set_visible(False)
    marg.tick_params(length=0)

# Counts, read off the shaded side of each marginal.
g.ax_marg_x.text(-XLIM * 0.97, 0.72, f"← earlier: {earlier}/{len(frame)}",
                 transform=g.ax_marg_x.get_xaxis_transform(),
                 ha="left", va="center", fontsize=5.8, color=fs.MUTED)
g.ax_marg_y.text(0.72, YLIM * 0.97, f"stronger: {stronger}/{len(frame)} ↑",
                 transform=g.ax_marg_y.get_yaxis_transform(),
                 ha="center", va="top", rotation=-90,
                 fontsize=5.8, color=fs.MUTED)

# Legend below the panel, one row, so it stops sitting on the data.
handles = [Line2D([], [], marker="o", linestyle="none", markersize=2.8,
                  markerfacecolor=fs.SURVEY_COLOR[s], markeredgecolor="none",
                  label=fs.SURVEY_LABEL[s], alpha=0.85)
           for s in fs.SURVEYS]
ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, -0.16),
          ncol=5, frameon=False, fontsize=5.6, columnspacing=0.9,
          handletextpad=0.25, borderpad=0.0)

g.savefig(f"{fs.HERE}/03_block_updates.pdf", bbox_inches="tight", facecolor="white")
g.savefig(f"{fs.HERE}/03_block_updates.png", dpi=300, bbox_inches="tight", facecolor="white")
plt.close()
