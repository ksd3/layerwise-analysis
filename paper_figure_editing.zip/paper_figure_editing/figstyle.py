"""Shared style for the four headline figures.

Figures are drawn at the NeurIPS text width (5.5 in) so every font size in the
PDF is the size that appears on the printed page.  The survey palette is fixed
across all figures (color follows the survey, never the panel) and was checked
for color-vision-deficiency separation; SDSS is deliberately gray because it is
the null cohort.
"""

from pathlib import Path

import matplotlib as mpl

HERE = Path(__file__).resolve().parent
DATA = HERE

# For compatibility with both direct imports and saves
__all__ = ["HERE", "DATA", "TEXT_WIDTH"]

TEXT_WIDTH = 5.5  # NeurIPS \textwidth in inches

# Ink and chrome
INK = "#243746"      # titles, strong reference lines
MUTED = "#66788a"    # secondary text, axis labels, ticks
AXIS = "#a3b0ba"     # spines
GRID = "#e4e9ed"     # hairline gridlines

# Reserved accents (never used for a survey)
RED = "#c13b3b"      # negative results / failures
WASH_RED = "#faf1ef"
WASH_BLUE = "#eef4fa"

SURVEYS = ["cosmosweb", "desi", "jwst", "legacysurvey", "sdss"]
SURVEY_LABEL = {
    "cosmosweb": "COSMOS-Web",
    "desi": "DESI",
    "jwst": "JWST",
    "legacysurvey": "Legacy Survey",
    "sdss": "SDSS",
}
SURVEY_COLOR = {
    "cosmosweb": "#2a78d6",
    "desi": "#4a3aa7",
    "jwst": "#eb6834",
    "legacysurvey": "#1baf7a",
    "sdss": "#9aa8b1",  # gray: the null cohort
}


def apply_style():
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Liberation Sans", "Nimbus Sans", "DejaVu Sans"],
            "font.size": 7.0,
            "axes.titlesize": 7.5,
            "axes.titleweight": "bold",
            "axes.titlecolor": INK,
            "axes.labelsize": 7.0,
            "axes.labelcolor": MUTED,
            "axes.edgecolor": AXIS,
            "axes.linewidth": 0.6,
            "xtick.labelsize": 6.3,
            "ytick.labelsize": 6.3,
            "xtick.color": AXIS,
            "ytick.color": AXIS,
            "xtick.labelcolor": MUTED,
            "ytick.labelcolor": MUTED,
            "xtick.major.size": 2.2,
            "ytick.major.size": 2.2,
            "xtick.major.width": 0.6,
            "ytick.major.width": 0.6,
            "legend.fontsize": 6.3,
            "text.color": INK,
            "figure.facecolor": "white",
            "savefig.facecolor": "white",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )


def style_axis(ax, grid="y"):
    """Recessive chrome: no top/right spines, hairline solid grid below the data."""
    ax.spines[["top", "right"]].set_visible(False)
    if grid:
        ax.grid(axis=grid, color=GRID, linewidth=0.5)
        ax.set_axisbelow(True)


def panel_letter(ax, letter, x=-0.24, y=1.12):
    ax.text(x, y, letter, transform=ax.transAxes, fontsize=8.5, fontweight="bold",
            color=INK, ha="left", va="baseline")


def save(fig, stem):
    fig.savefig(HERE / f"{stem}.pdf")
    fig.savefig(HERE / f"{stem}.png", dpi=300)
